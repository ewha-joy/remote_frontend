export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const INTEGRATE_WALLET = 'INTEGRATE_WALLET'
export const REMOVE_WALLET = 'REMOVE_WALLET'

